#!/usr/bin/env bash
set -euo pipefail
# ---------------------------------------------------------------------------
# Vault secret loader v2 — "Ansible-like" minimal input.
#
# Like the ibm.mas_devops roles, this GENERATES or DERIVES everything it can,
# so you only supply the three genuinely-external things:
#     IBM_ENTITLEMENT_KEY   MAS_LICENSE_FILE   JDBC_* (external Oracle)
#
# Behaviour per secret:
#   REQUIRE  = you must export it (no one can invent it)
#   DERIVE   = read from the in-cluster mas-mongo-ce  (AUTO_MONGO, default on)
#   GENERATE = create a strong random value, but ONLY if not already in Vault
#              (generate-once: re-runs reuse existing values — crypto keys and
#               the superuser password MUST stay stable)
#   HARVEST  = filled later by scripts/harvest-sls-registration.sh (own-SLS)
#
# Override any GENERATE/DERIVE value by exporting it yourself (then it's used
# verbatim, still stored once). render.py fills ${...}.
#
# RUN:  export VAULT_TOKEN=... ; export the 3 REQUIRE vars ; ./<cluster>-load-secrets.sh
# ---------------------------------------------------------------------------
PREFIX="secret/${ACCOUNT_ID}/${CLUSTER_ID}"
IPREFIX="secret/${ACCOUNT_ID}/${CLUSTER_ID}/${INSTANCE_ID}"
KV="${KV_MOUNT:-secret}"
VAULT_NS="${VAULT_NS:-vault}"; VAULT_POD="${VAULT_POD:-vault-0}"
VADDR="${VADDR:-http://127.0.0.1:8200}"
AUTO_MONGO="${AUTO_MONGO:-1}"; MONGO_CE_NS="${MONGO_CE_NS:-mongoce}"
[[ -z "${VAULT_TOKEN:-}" ]] && { echo "ERROR: export VAULT_TOKEN first" >&2; exit 1; }
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
vrun(){ oc exec -n "$VAULT_NS" "$VAULT_POD" -- sh -c \
  "export VAULT_ADDR=$VADDR VAULT_TOKEN='$VAULT_TOKEN'; $*"; }
vget(){ vrun "vault kv get -field='$2' $KV/$1" 2>/dev/null || true; }
gen(){ openssl rand -base64 "${1:-24}" | tr -d '/+=' | cut -c1-"${2:-24}"; }
genhex(){ openssl rand -hex "${1:-32}"; }

# ---- REQUIRE: the only true human inputs (same as Ansible) ----
: "${IBM_ENTITLEMENT_KEY:?REQUIRED}"; : "${MAS_LICENSE_FILE:?REQUIRED path to license.dat}"
: "${JDBC_USERNAME:?REQUIRED}"; : "${JDBC_PASSWORD:?REQUIRED}"; : "${JDBC_URL:?REQUIRED}"
: "${JDBC_CA_CRT:?REQUIRED path to Oracle CA PEM}"; : "${MAS_LICENSE_ID:=}"

# ---- GENERATE-once: reuse what's already in Vault, else make it ----
MAS_SUPERUSER_USERNAME="${MAS_SUPERUSER_USERNAME:-$(vget "$IPREFIX/superuser" username)}"; MAS_SUPERUSER_USERNAME="${MAS_SUPERUSER_USERNAME:-superuser}"
MAS_SUPERUSER_PASSWORD="${MAS_SUPERUSER_PASSWORD:-$(vget "$IPREFIX/superuser" password)}"; MAS_SUPERUSER_PASSWORD="${MAS_SUPERUSER_PASSWORD:-$(gen 24 24)}"
MANAGE_CRYPTO_KEY="${MANAGE_CRYPTO_KEY:-$(vget "$IPREFIX/manage-crypto" cryptoKey)}";   MANAGE_CRYPTO_KEY="${MANAGE_CRYPTO_KEY:-$(genhex 32)}"
MANAGE_CRYPTOX_KEY="${MANAGE_CRYPTOX_KEY:-$(vget "$IPREFIX/manage-crypto" cryptoxKey)}"; MANAGE_CRYPTOX_KEY="${MANAGE_CRYPTOX_KEY:-$(genhex 32)}"
SLS_MONGO_USERNAME="${SLS_MONGO_USERNAME:-$(vget "$IPREFIX/sls-mongo" username)}"; SLS_MONGO_USERNAME="${SLS_MONGO_USERNAME:-slsmongo}"
SLS_MONGO_PASSWORD="${SLS_MONGO_PASSWORD:-$(vget "$IPREFIX/sls-mongo" password)}"; SLS_MONGO_PASSWORD="${SLS_MONGO_PASSWORD:-$(gen 24 24)}"

# ---- DERIVE from the in-cluster mongo (like the mongodb role) ----
if [[ "$AUTO_MONGO" == "1" ]]; then
  MONGO_USERNAME="${MONGO_USERNAME:-admin}"
  MONGO_PASSWORD="${MONGO_PASSWORD:-$(oc get secret mas-mongo-ce-admin-password -n "$MONGO_CE_NS" -o jsonpath='{.data.password}' | base64 -d)}"
  MONGO_HOST="${MONGO_HOST:-mas-mongo-ce-svc.${MONGO_CE_NS}.svc.cluster.local}"
  if [[ -z "${MONGO_CA_CRT:-}" ]]; then
    oc extract secret/mongo-ca-secret -n "$MONGO_CE_NS" --keys=ca.crt --to="$TMP" --confirm >/dev/null; MONGO_CA_CRT="$TMP/ca.crt"
  fi
  SLS_MONGO_CA_CRT="${SLS_MONGO_CA_CRT:-$MONGO_CA_CRT}"
fi
: "${MONGO_USERNAME:?}"; : "${MONGO_PASSWORD:?}"; : "${MONGO_HOST:?}"; : "${MONGO_CA_CRT:?}"
: "${SLS_MONGO_CA_CRT:?}"

putfile(){ oc cp "$1" "$VAULT_NS/$VAULT_POD:/tmp/$2"; }

# entitlement -> base64(dockerconfigjson)
ENC="$(printf 'cp:%s' "$IBM_ENTITLEMENT_KEY" | base64 -w0)"
DOCKERCFG="$(printf '{"auths":{"cp.icr.io":{"auth":"%s"}}}' "$ENC" | base64 -w0)"
vrun "vault kv put $PREFIX/entitlement image_pull_secret_b64='$DOCKERCFG'"
# license -> base64 -w0 (folded scalar)
vrun "vault kv put $IPREFIX/license license_id='$MAS_LICENSE_ID' license_file='$(base64 -w0 "$MAS_LICENSE_FILE")'"
# generated/derived
vrun "vault kv put $IPREFIX/superuser username='$MAS_SUPERUSER_USERNAME' password='$MAS_SUPERUSER_PASSWORD'"
vrun "vault kv put $IPREFIX/manage-crypto cryptoKey='$MANAGE_CRYPTO_KEY' cryptoxKey='$MANAGE_CRYPTOX_KEY'"
putfile "$JDBC_CA_CRT" jdbc-ca.pem
vrun "vault kv put $IPREFIX/jdbc-system username='$JDBC_USERNAME' password='$JDBC_PASSWORD' jdbc_url='$JDBC_URL' ca.crt=@/tmp/jdbc-ca.pem"
putfile "$MONGO_CA_CRT" mongo-ca.pem
vrun "vault kv put $IPREFIX/mongo username='$MONGO_USERNAME' password='$MONGO_PASSWORD' host='$MONGO_HOST' ca.crt=@/tmp/mongo-ca.pem"
putfile "$SLS_MONGO_CA_CRT" sls-mongo-ca.pem
vrun "vault kv put $IPREFIX/sls-mongo username='$SLS_MONGO_USERNAME' password='$SLS_MONGO_PASSWORD' ca.crt=@/tmp/sls-mongo-ca.pem"
vrun "rm -f /tmp/jdbc-ca.pem /tmp/mongo-ca.pem /tmp/sls-mongo-ca.pem" || true

echo ">> Loaded. Generated values are stored once and reused on re-run."
echo ">> sls#registration_key/url/ca is HARVESTED after SLS is Ready:"
echo "     scripts/harvest-sls-registration.sh envs/${CLUSTER_ID}.env"
echo ">> Verify: scripts/preflight-vault.sh envs/${CLUSTER_ID}.env"
