#!/usr/bin/env bash
set -euo pipefail
# ---------------------------------------------------------------------------
# Durable Vault Kubernetes-auth setup for ArgoCD Vault Plugin (AVP).
#
# WHY THIS REPLACES THE OLD SCRIPT:
#   The previous version did `oc create token default --duration=24h` and used
#   that as token_reviewer_jwt. Bound SA tokens EXPIRE (K8s 1.24+), so ~24h
#   later every AVP login failed with 403 "permission denied" and all syncs
#   broke until the JWT was rewritten by hand. This version never expires.
#
# HOW IT'S DURABLE:
#   We OMIT token_reviewer_jwt entirely. With no reviewer JWT configured, Vault
#   uses the CLIENT's own (live, auto-rotated) pod token to call the
#   TokenReview API at login time. That only works if the client SA holds
#   system:auth-delegator, which this script grants. Nothing to renew.
#
#   Set DEDICATED_REVIEWER=1 if your security team requires an explicit
#   reviewer identity instead — it creates a dedicated SA with a non-expiring
#   token Secret and wires that in as token_reviewer_jwt.
#
# RUN: export VAULT_TOKEN=<root/admin>; ./setup-vault-auth.sh
# Re-runnable / idempotent.
# ---------------------------------------------------------------------------
NS_GITOPS="${NS_GITOPS:-openshift-gitops}"
VAULT_NS="${VAULT_NS:-vault}"
VAULT_POD="${VAULT_POD:-vault-0}"
VADDR="${VADDR:-http://127.0.0.1:8200}"
ROLE="${ROLE:-mas-gitops}"
POLICY="${POLICY:-mas-gitops}"
KV_MOUNT="${KV_MOUNT:-secret}"
DEDICATED_REVIEWER="${DEDICATED_REVIEWER:-0}"

# AVP runs inside the repo-server pod, so the SA used for Vault login is the
# repo-server pod's serviceAccountName. DETECT it instead of assuming "default".
REPO_SA="${REPO_SA:-$(oc get deploy openshift-gitops-repo-server -n "$NS_GITOPS" \
  -o jsonpath='{.spec.template.spec.serviceAccountName}' 2>/dev/null)}"
REPO_SA="${REPO_SA:-default}"
echo ">> repo-server service account = ${REPO_SA} (ns ${NS_GITOPS})"

[[ -z "${VAULT_TOKEN:-}" ]] && { echo "ERROR: export VAULT_TOKEN first" >&2; exit 1; }

vx() { oc exec -n "$VAULT_NS" "$VAULT_POD" -- sh -c \
  "export VAULT_ADDR=$VADDR VAULT_TOKEN='$VAULT_TOKEN'; $*"; }

echo ">> enable kv-v2 at '$KV_MOUNT' (no-op if present)"
vx "vault secrets enable -path=$KV_MOUNT kv-v2 || true"

echo ">> write policy '$POLICY'"
oc cp "$(dirname "$0")/mas-gitops-policy.hcl" "$VAULT_NS/$VAULT_POD:/tmp/p.hcl"
vx "vault policy write $POLICY /tmp/p.hcl"

echo ">> enable kubernetes auth (no-op if present)"
vx "vault auth enable kubernetes || true"

echo ">> grant client SA system:auth-delegator (required for live-token review)"
oc adm policy add-cluster-role-to-user system:auth-delegator \
  "system:serviceaccount:${NS_GITOPS}:${REPO_SA}" || true

if [[ "$DEDICATED_REVIEWER" == "1" ]]; then
  echo ">> DEDICATED_REVIEWER mode: create non-expiring reviewer token"
  oc create sa vault-auth-reviewer -n "$VAULT_NS" --dry-run=client -o yaml | oc apply -f -
  oc adm policy add-cluster-role-to-user system:auth-delegator \
    "system:serviceaccount:${VAULT_NS}:vault-auth-reviewer" || true
  cat <<EOF | oc apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: vault-auth-reviewer-token
  namespace: ${VAULT_NS}
  annotations:
    kubernetes.io/service-account.name: vault-auth-reviewer
type: kubernetes.io/service-account-token
EOF
  # wait for the controller to populate the token
  for i in $(seq 1 15); do
    oc get secret vault-auth-reviewer-token -n "$VAULT_NS" \
      -o jsonpath='{.data.token}' 2>/dev/null | grep -q . && break; sleep 2
  done
  oc get secret vault-auth-reviewer-token -n "$VAULT_NS" \
    -o jsonpath='{.data.token}' | base64 -d > /tmp/reviewer.jwt
  oc cp /tmp/reviewer.jwt "$VAULT_NS/$VAULT_POD:/tmp/reviewer.jwt"; rm -f /tmp/reviewer.jwt
  vx "vault write auth/kubernetes/config \
        kubernetes_host=\"https://\${KUBERNETES_SERVICE_HOST}:\${KUBERNETES_SERVICE_PORT}\" \
        kubernetes_ca_cert=@/var/run/secrets/kubernetes.io/serviceaccount/ca.crt \
        token_reviewer_jwt=@/tmp/reviewer.jwt \
        disable_iss_validation=true"
else
  echo ">> DURABLE mode: configure auth WITHOUT token_reviewer_jwt (uses live client token)"
  vx "vault write auth/kubernetes/config \
        kubernetes_host=\"https://\${KUBERNETES_SERVICE_HOST}:\${KUBERNETES_SERVICE_PORT}\" \
        kubernetes_ca_cert=@/var/run/secrets/kubernetes.io/serviceaccount/ca.crt \
        disable_iss_validation=true"
fi

echo ">> write role '$ROLE' bound to ${REPO_SA}"
vx "vault write auth/kubernetes/role/$ROLE \
      bound_service_account_names='$REPO_SA' \
      bound_service_account_namespaces='$NS_GITOPS' \
      policies='$POLICY' ttl=1h"

echo ">> verify"
vx "vault read auth/kubernetes/config" || true
vx "vault read auth/kubernetes/role/$ROLE"
echo ">> DONE. This config survives token expiry. Re-run only if SA/policy changes."
