# IBM MAS GitOps - End-to-End Setup Guide

This is the complete start-to-finish guide for the IBM-aligned, hub-and-spoke MAS GitOps setup in
this package. It ties together the per-topic runbooks (`ORACLE-TLS.md`, `MONGODB.md`,
`PER-CLUSTER-PREREQUISITES.md`). Follow the phases in order.

## What you are building
```
Management OpenShift cluster (the hub)
  OpenShift GitOps / ArgoCD        one instance
  HashiCorp Vault + ArgoCD Vault Plugin (AVP)   one Vault, resolves all secrets centrally
  ONE IBM MAS Account Root Application
     discovers each config-repo mas/<cluster>/ directory
     deploys MAS + Manage out to the registered Target (spoke) clusters: drroc4, roc4, ...
External to the clusters: Oracle (TLS), MongoDB (per spoke, via Ansible)
```
Three Git repos: `platform-repo` (hub bootstrap), `config-repo` (renders MAS config), and a verbatim
mirror of IBM `ibm-mas/gitops` tag `8.0.0`.

## Key decisions baked into this package
- Secrets backend is HashiCorp Vault via AVP (on-prem). IBM documents AWS Secrets Manager as the
  supported backend; this is a working on-prem pattern - validate support expectations for production.
- The IBM source mirror is PRISTINE (tag 8.0.0, no patches). All customization is in your two repos.
- External Oracle uses the STOCK JDBC chart, so Oracle must be TLS (TCPS) enabled (Option A).
- MongoDB is deployed by the Ansible `mongodb` role per spoke; GitOps owns only the `MongoCfg` pointer.
- Manage runs all-in-one (`aio.install: true`).
- Sync is manual (no auto-sync), so upgrades/changes apply on your schedule.

---

## Phase 0 - Prerequisites and inputs to gather
Clusters: one management cluster, plus each target/spoke (drroc4, roc4). Management cluster must have
network reachability to each spoke API (`:6443`).

Accounts/keys: IBM entitlement key, MAS license file (`license.dat`), SLS license id.

External dependencies (per spoke): external Oracle reachable over TCPS + its CA PEM (see ORACLE-TLS.md);
the `isilon` PowerScale storage class installed (RWX for Manage, RWO for Mongo); MongoDB (stood up in
Phase 5 via Ansible).

Tooling on your workstation/bastion: `oc`, `argocd`, `helm`, `git`, `vault`, and either the
`ibm.mas_devops` Ansible collection or the `quay.io/ibmmas/cli` image (for the MongoDB role).

GitLab: empty repos for `platform-repo`, `config-repo`, and `ibm-mas-gitops` (the mirror).

---

## Phase 1 - Mirror the IBM source repo (verbatim)
```bash
cd ibm-mas-gitops-source-mirror
export DEST=https://gitlab.example/your-group/ibm-mas-gitops.git
./mirror-tag-8.0.0.sh        # clones IBM tag 8.0.0 and pushes it to your GitLab, no local changes
```
Result: an internal read-only copy of IBM 8.0.0. Nothing here is modified.

---

## Phase 2 - Push your repos and create ArgoCD repo credentials
1. Push `platform-repo/` and `config-repo/` to their GitLab repos.
2. Edit `platform-repo/repo-secrets/*.yaml` with real repo URLs + tokens for all THREE repos
   (platform, config, source mirror) and apply them on the management cluster (namespace
   `openshift-gitops`) so ArgoCD can read each repo.

---

## Phase 3 - Bootstrap the management cluster (hub)
1. Install the OpenShift GitOps operator (gives you ArgoCD in `openshift-gitops`).
2. Edit `platform-repo/values-management.yaml`: set the three repo URLs and the Vault host/address.
3. Deploy + initialize Vault:
   - The `platform-repo/charts/management-bootstrap` chart deploys Vault (PVCs use `vault.storageClass: isilon`).
   - Initialize and unseal Vault (`vault operator init`, then `vault operator unseal`). Store the unseal
     keys and root token securely (raft snapshots + these keys are your Vault DR - see note below).
   - Configure Vault for AVP:  `cd platform-repo/vault && ./setup-vault.sh`
     (enables the KV v2 mount, loads `vault-policy-mas-gitops.hcl`, and sets up the auth role `mas-gitops`).
4. Enable AVP in ArgoCD: apply `platform-repo/argocd/argocd-cr-avp-sidecar-patch.yaml` to add the AVP
   sidecar to the repo-server. FIRST confirm your OpenShift GitOps operator version supports the CR
   fields used; adjust to match your operator if needed.
5. Apply the account root:  `oc apply -f platform-repo/bootstrap.yaml`
   This creates the single IBM MAS Account Root Application. It will show empty/healthy until clusters
   and config exist.

Vault DR note: the hub's Vault is the at-risk piece. Take regular raft snapshots and keep the unseal
keys offline. If the hub is lost, spokes keep running; you rebuild the hub, restore Vault, re-register
spokes, and ArgoCD re-adopts the existing MAS resources.

---

## Phase 4 - Register each target (spoke) cluster
```bash
cd platform-repo/cluster-registration
./register-cluster.sh drroc4 <kube-context-for-drroc4>
argocd cluster list        # note the exact server URL it stored
```
Put that EXACT server URL into `config-repo/.../mas/drroc4/ibm-mas-cluster-base.yaml` as `cluster.url`
(it must match byte-for-byte). Repeat per spoke. For OCP 4.11+ also apply
`argocd-manager-token-secret.yaml` on the spoke so the token does not expire. (Declarative alternative
to the script: `cluster-secret-template.yaml`.)

---

## Phase 5 - Per-cluster prerequisites (EACH spoke, before sync)
Full checklist: `PER-CLUSTER-PREREQUISITES.md`. Summary:
1. Cluster registered (Phase 4) with matching `cluster.url`.
2. `isilon` storage class present on the spoke (PowerScale CSI installed).
3. Exactly one cert-manager - if Dell CSM is on the spoke, disable its bundled cert-manager.
4. MongoDB deployed via the Ansible `mongodb` role - see `MONGODB.md`.
5. Oracle reachable over TLS (TCPS) and its CA in hand - see `ORACLE-TLS.md`.
6. Vault secrets loaded for that cluster/instance (Phase 6 loader).

---

## Phase 6 - Configure, load secrets, render
1. Fill the `CHANGE_ME` values in `config-repo/envs/<cluster>.env` (and add a new env file per new
   cluster; `env3.env.example` / `env4.env.example` are templates).
2. Load that cluster's secrets into Vault:
   ```bash
   cd config-repo/vault
   # provide values via env, then run the generated loader, e.g.:
   ./drroc4-load-secrets.sh
   ```
   Loads: entitlement, jdbc-system (username/password/jdbc_url=TCPS string/ca.crt=Oracle CA),
   sls + sls-mongo, mongo (host/user/pass/ca from the Ansible deployment), license.
3. Render and commit:
   ```bash
   cd config-repo
   ./render.sh --all
   git add mas/ envs/ && git commit -m "config" && git push
   ```
   Never edit `mas/` by hand - edit `base/` or `envs/` and re-render.

---

## Phase 7 - Sync
In the management ArgoCD, sync in dependency order (manual gates):
1. Cluster-scope (cluster base: cert-manager, operator catalog, DRO).
2. SLS.
3. MAS Suite (core).
4. Manage app install + config.
Sync one spoke fully, confirm it is healthy, then move to the next.

---

## Phase 8 - Verify
- ArgoCD: all Applications Synced + Healthy.
- `oc get suite -n mas-<instance>-core` -> Ready/running.
- `oc get manageworkspace -n mas-<instance>-manage` -> running; pods up.
- Log in to the MAS admin URL and the Manage workspace.

---

## Day-2 operations
- Upgrade / patch: bump `MAS_CATALOG_VERSION` (and `MAS_CHANNEL` / `MAS_APP_CHANNEL` for minor/major)
  in `envs/<cluster>.env`, re-render, commit, sync. Per-cluster, so you can canary one spoke first.
  Forward-only; downgrades are not supported - rely on backups.
- Add a cluster: new `envs/<cluster>.env` -> render -> register the spoke (Phase 4) -> per-cluster
  prerequisites (Phase 5) -> sync.
- Trusted certs into MAS: add to `ibm-mas-suite.yaml` `suite_spec_additional_properties.certificates`,
  PEM from Vault (see notes on cert paths).
- Rotate secrets: update Vault, re-sync (AVP re-resolves at sync).
- MongoDB backup/restore + version upgrades: Ansible `mongodb` role (see `MONGODB.md`).

## Where things live
```
platform-repo/        hub: Vault chart, AVP patch, repo secrets, cluster registration, account root
config-repo/          base/ templates + envs/<cluster>.env -> render.py -> mas/ (+ vault/ loaders)
ibm-mas-gitops-source-mirror/   verbatim IBM 8.0.0 mirror script (pristine)
docs/                 this guide + ORACLE-TLS.md + MONGODB.md + PER-CLUSTER-PREREQUISITES.md
```
