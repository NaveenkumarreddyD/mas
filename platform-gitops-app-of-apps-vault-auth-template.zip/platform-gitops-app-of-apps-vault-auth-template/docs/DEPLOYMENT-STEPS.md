# Deployment steps

## Phase 1: Git trust and repo credentials

```bash
oc apply -f bootstrap/00-gitlab-ca-configmap.yaml
oc apply -f bootstrap/01-argocd-cluster-admin-rbac.yaml
oc apply -f <real-repo-creds-secret.yaml>
oc rollout restart deploy/openshift-gitops-repo-server -n openshift-gitops
```

## Phase 2: bootstrap app-of-apps app

```bash
oc apply -f bootstrap.yaml
```

Sync `platform-app-of-apps`, then sync `hashicorp-vault-server`.

## Phase 3: Vault init/unseal and auth

```bash
oc exec -n vault vault-0 -- vault operator init
export VAULT_TOKEN='<root-or-admin-token>'
./vault-auth/setup-vault-auth.sh
```

## Phase 4: AVP sidecar

```bash
oc patch argocd openshift-gitops -n openshift-gitops --type merge --patch-file argocd/argocd-cr-avp-sidecar-patch.yaml
oc rollout restart deploy/openshift-gitops-repo-server -n openshift-gitops
oc rollout status deploy/openshift-gitops-repo-server -n openshift-gitops
./vault-auth/test-avp.sh
```

## Phase 5: MAS

Do not sync `ibm-mas-account-root` until target clusters are registered, MAS config repo is pushed, real MAS secrets are loaded, and AVP test passes.
