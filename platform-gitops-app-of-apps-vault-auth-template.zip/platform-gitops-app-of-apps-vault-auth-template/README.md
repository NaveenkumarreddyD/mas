# platform-gitops

This repository bootstraps the IBM MAS GitOps management cluster platform components.

It uses the ArgoCD App-of-Apps pattern:

```text
bootstrap.yaml
  -> platform-app-of-apps
      -> hashicorp-vault-server
      -> argocd-vault-plugin
      -> ibm-mas-account-root
```

## Layout

```text
platform-gitops/
├── bootstrap/
│   ├── 00-gitlab-ca-configmap.yaml
│   └── 01-argocd-cluster-admin-rbac.yaml
├── repo-creds/
│   └── gitlab-group-repo-creds.example.yaml
├── charts/
│   └── app-of-apps/
│       ├── Chart.yaml
│       ├── values.yaml
│       └── templates/
│           ├── 00-app-project.yaml
│           ├── 10-hashicorp-vault-server.yaml
│           ├── 20-argocd-vault-plugin.yaml
│           └── 30-ibm-mas-account-root.yaml
├── argocd/
│   ├── cmp-plugin-configmap.yaml
│   ├── argocd-vault-plugin-credentials.example.yaml
│   ├── argocd-vault-plugin-credentials.aws-example.yaml
│   ├── argocd-cr-avp-sidecar-patch.yaml
│   └── argocd-cr-avp-sidecar-patch-internal-image.example.yaml
├── values/
│   └── values-management.yaml
├── vault-auth/
│   ├── mas-gitops-policy.hcl
│   ├── setup-vault-auth.md
│   ├── setup-vault-auth.sh
│   └── test-avp.sh
├── scripts/
│   ├── verify-platform.sh
│   └── validate-files.sh
├── docs/
│   └── DEPLOYMENT-STEPS.md
├── bootstrap.yaml
└── README.md
```

## Folder meaning

- `bootstrap/`: one-time cluster-admin prerequisites such as GitLab CA trust and ArgoCD permissions.
- `repo-creds/`: example GitLab group credential template. Do not commit real tokens.
- `charts/app-of-apps/`: parent Helm chart that creates child ArgoCD Applications.
- `argocd/`: AVP/CMP and repo-server sidecar configuration.
- `values/`: management environment values used by the app-of-apps chart.
- `vault-auth/`: post-install Vault policy/auth/test scripts. This does not install Vault.
- `docs/`: deployment guide and manifest list.

## First install summary

1. Apply GitLab CA trust and ArgoCD RBAC from `bootstrap/`.
2. Create the real repo credentials secret from `repo-creds/gitlab-group-repo-creds.example.yaml`.
3. Update `values/values-management.yaml`.
4. Apply `bootstrap.yaml`.
5. Sync `hashicorp-vault-server`.
6. Initialize/unseal Vault manually.
7. Run `vault-auth/setup-vault-auth.sh`.
8. Apply/verify AVP sidecar patch from `argocd/`.
9. Run `vault-auth/test-avp.sh`.
10. Load real MAS secrets into Vault.
11. Sync `ibm-mas-account-root` only after prerequisites are ready.

## Security notes

Do not commit real GitLab tokens, Vault root tokens, unseal keys, MAS passwords, license files, private keys, or entitlement keys.
