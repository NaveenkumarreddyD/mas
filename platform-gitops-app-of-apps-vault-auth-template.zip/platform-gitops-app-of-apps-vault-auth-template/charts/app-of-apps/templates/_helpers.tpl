{{- define "appofapps.vaultAddr" -}}
{{- if .Values.avp.vaultAddr -}}{{ .Values.avp.vaultAddr }}{{- else -}}https://{{ .Values.vault.host }}{{- end -}}
{{- end -}}
