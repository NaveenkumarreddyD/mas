#!/usr/bin/env bash
set -euo pipefail
NAMESPACE_OPENSHIFT_GITOPS="${NAMESPACE_OPENSHIFT_GITOPS:-openshift-gitops}"
VAULT_NAMESPACE="${VAULT_NAMESPACE:-vault}"
VAULT_POD="${VAULT_POD:-vault-0}"
VAULT_ADDR_IN_POD="${VAULT_ADDR_IN_POD:-http://127.0.0.1:8200}"
VAULT_ROLE="${VAULT_ROLE:-mas-gitops}"
VAULT_POLICY="${VAULT_POLICY:-mas-gitops}"
REPO_SA="${REPO_SA:-default}"
if [[ -z "${VAULT_TOKEN:-}" ]]; then echo "ERROR: export VAULT_TOKEN first" >&2; exit 1; fi
K8S_HOST="$(oc whoami --show-server)"
TMPDIR="$(mktemp -d)"; trap 'rm -rf "$TMPDIR"' EXIT
oc create token "${REPO_SA}" -n "${NAMESPACE_OPENSHIFT_GITOPS}" --duration=24h > "${TMPDIR}/repo-server-token.txt"
oc get cm kube-root-ca.crt -n "${NAMESPACE_OPENSHIFT_GITOPS}" -o jsonpath='{.data.ca\.crt}' > "${TMPDIR}/kube-ca.crt"
oc cp "${TMPDIR}/repo-server-token.txt" "${VAULT_NAMESPACE}/${VAULT_POD}:/tmp/repo-server-token.txt"
oc cp "${TMPDIR}/kube-ca.crt" "${VAULT_NAMESPACE}/${VAULT_POD}:/tmp/kube-ca.crt"
oc exec -n "${VAULT_NAMESPACE}" "${VAULT_POD}" -- sh -c "export VAULT_ADDR=${VAULT_ADDR_IN_POD}; export VAULT_TOKEN='${VAULT_TOKEN}'; vault secrets enable -path=secret kv-v2 || true"
oc cp "$(dirname "$0")/mas-gitops-policy.hcl" "${VAULT_NAMESPACE}/${VAULT_POD}:/tmp/mas-gitops-policy.hcl"
oc exec -n "${VAULT_NAMESPACE}" "${VAULT_POD}" -- sh -c "export VAULT_ADDR=${VAULT_ADDR_IN_POD}; export VAULT_TOKEN='${VAULT_TOKEN}'; vault policy write ${VAULT_POLICY} /tmp/mas-gitops-policy.hcl"
oc exec -n "${VAULT_NAMESPACE}" "${VAULT_POD}" -- sh -c "export VAULT_ADDR=${VAULT_ADDR_IN_POD}; export VAULT_TOKEN='${VAULT_TOKEN}'; vault auth enable kubernetes || true"
oc exec -n "${VAULT_NAMESPACE}" "${VAULT_POD}" -- sh -c "export VAULT_ADDR=${VAULT_ADDR_IN_POD}; export VAULT_TOKEN='${VAULT_TOKEN}'; vault write auth/kubernetes/config token_reviewer_jwt=\"\$(cat /tmp/repo-server-token.txt)\" kubernetes_host='${K8S_HOST}' kubernetes_ca_cert=@/tmp/kube-ca.crt"
oc exec -n "${VAULT_NAMESPACE}" "${VAULT_POD}" -- sh -c "export VAULT_ADDR=${VAULT_ADDR_IN_POD}; export VAULT_TOKEN='${VAULT_TOKEN}'; vault write auth/kubernetes/role/${VAULT_ROLE} bound_service_account_names='${REPO_SA}' bound_service_account_namespaces='${NAMESPACE_OPENSHIFT_GITOPS}' policies='${VAULT_POLICY}' ttl=1h"
oc adm policy add-cluster-role-to-user system:auth-delegator "system:serviceaccount:${NAMESPACE_OPENSHIFT_GITOPS}:${REPO_SA}" || true
oc exec -n "${VAULT_NAMESPACE}" "${VAULT_POD}" -- sh -c "export VAULT_ADDR=${VAULT_ADDR_IN_POD}; export VAULT_TOKEN='${VAULT_TOKEN}'; vault read auth/kubernetes/role/${VAULT_ROLE}"
