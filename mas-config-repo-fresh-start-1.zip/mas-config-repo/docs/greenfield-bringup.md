# Greenfield bring-up — fresh GitOps install of drgitopsapp

Assumes: empty of any prior drgitopsapp install (see uninstall-gitops.md), MongoDB Community
already running and reachable, `platform-gitops` bootstrap (Vault + AVP + account-root) in place.

## 1. Align versions to Ansible (do this FIRST)
```bash
scripts/gather-ansible-versions.sh
```
Paste the printed channel + catalog-digest values into `envs/drroc4.env`, then:
```bash
./render.sh drroc4
git add -A && git commit -m "drgitopsapp: align versions to drmasapp (Ansible)" && git push
```
See `docs/version-alignment.md` for why the catalog digest matters.

## 2. Seed Vault
```bash
bash vault/drroc4-load-secrets.sh     # entitlement key, license.dat, mongo, sls-mongo, jdbc, crypto
```
Leave `secret/mas/drroc4/drgitopsapp/sls#{url,registration_key,ca.crt}` EMPTY for now —
SLS generates those at runtime (step 5).

## 3. Let GitOps reconcile cluster-base + SLS
Sync the account-root; cluster-base (catalog/cert-manager/DRO) and the instance SLS deploy.
SLS reads the license from Vault via the `ibm-sls-sls-entitlement` secret.

## 4. Wait for SLS to license itself
```bash
oc get licenseservice sls -n mas-drgitopsapp-sls
# INITIALIZED must read 'Initialized', NOT 'MissingConfiguration'.
```
If `MissingConfiguration`: the license didn't apply. Check the entitlement secret content matches
the known-good Ansible one:
```bash
oc get secret ibm-sls-sls-entitlement -n mas-drgitopsapp-sls -o jsonpath='{.data.entitlement}' | base64 -d | head -c 80; echo
oc get secret ibm-sls-sls-entitlement -n ibm-sls               -o jsonpath='{.data.entitlement}' | base64 -d | head -c 80; echo
```
Fix the Vault `license#license_file` content/format to match, re-sync.

## 5. Hand SLS registration to MAS Core (manual under Vault)
```bash
scripts/capture-sls-registration.sh           # reads SLS runtime values -> writes Vault sls#*
argocd app sync drgitopsapp-sls-system.drroc4  # SlsCfg now resolves
```

## 6. Bring up Core, then defer/Manage
```bash
argocd app sync mongo... sls... suite...        # Core: Mongo + SLS + Suite
oc get suite -n mas-drgitopsapp-core
```
JDBC (Oracle) + Manage stay deferred until Oracle details exist.

## 7. Verify parity with Ansible
```bash
ANSIBLE_INSTANCE_ID=drgitopsapp SLS_NS=mas-drgitopsapp-sls scripts/gather-ansible-versions.sh
```
The INSTALLED CSV versions must match drmasapp's. If not, see version-alignment.md.

## Oracle JDBC (non-SSL, matches Ansible)
Prereq: apply `patches/ibm-jdbc-config-ssl-toggle/` to the ibm-mas-gitops mirror (one-time).
Load the Oracle creds (no CA — SSL is off):
```bash
export JDBC_USERNAME=maximo
export JDBC_PASSWORD=maximo
export JDBC_URL='jdbc:oracle:thin:@//stl-dmasdb-21.lac1.biz:1521/DEMAS'
# (these flow into vault/drroc4-load-secrets.sh -> secret/mas/drroc4/drgitopsapp/jdbc-system)
```
The JdbcCfg renders `sslEnabled: false` with no certificates — identical to the Ansible install.

## cert-manager toggle
- **Empty/fresh cluster:** leave `redhat-cert-manager.yaml` in place (it renders by default) so GitOps
  installs cert-manager. This is the case this kit is built for.
- **Current shared cluster (PoC alongside Ansible):** Ansible already installed cert-manager cluster-wide,
  so delete the rendered `mas/drroc4/redhat-cert-manager.yaml` before committing (and re-add it for the
  real fresh build). cert-manager is cluster-scoped; two installs would collide.
