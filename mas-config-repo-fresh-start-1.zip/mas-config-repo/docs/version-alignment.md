# Matching GitOps versions to the Ansible install

## The catalog is the single master pin
Every MAS operator (Core, Manage, SLS, cert-manager, DRO, truststore-mgr) is installed by OLM
from the **IBM operator catalog** using a channel (e.g. `8.11.x`, `3.x`, `8.7.x`) + `Automatic`
install plan. With Automatic + a channel, OLM installs whatever CSV is the channel HEAD **in the
catalog content at sync time**. So two things determine the version: the channel, and the catalog content.

## Why a fresh install can drift from Ansible
The catalog tag `vX-YYMMDD-amd64` is **re-pushed in place** by IBM — the same tag points to different
digests over time. Ansible installed when the tag meant one digest; a fresh GitOps install today pulls
whatever that tag means now. That is why the cluster showed the shared `ibm-sls` on 3.12.2 while the
GitOps SLS resolved to 3.9.1 on the "same" tag.

## The fix: pin by digest
Set the catalog by digest, not tag, so OLM resolves a fixed channel head every time:
```
MAS_CATALOG_IMAGE=icr.io/cpopen/ibm-maximo-operator-catalog@sha256
MAS_CATALOG_VERSION=<digest from gather-ansible-versions.sh>
```
`gather-ansible-versions.sh` reads the running catalog pod's resolved `imageID` (the digest the cluster
is actually serving) and the channel of each Ansible Subscription, and prints the exact env block.

## Channels to confirm against Ansible
- `MAS_CHANNEL`     = `ibm-mas` sub channel in `mas-drmasapp-core`
- `MAS_APP_CHANNEL` = `ibm-mas-manage` sub channel in `mas-drmasapp-manage`
- `SLS_CHANNEL`     = `ibm-sls` sub channel (`ibm-sls` namespace)

## Proving parity
The `INSTALLED CSV` column from the gather script is the target. After the fresh install, re-run the
script against `drgitopsapp` and compare CSV-for-CSV with `drmasapp`. If Ansible runs a version that is
not the channel head at your pinned digest (e.g. it was partially upgraded), either accept the head or
align Ansible — GitOps with Automatic always tracks the head at the pinned digest.
