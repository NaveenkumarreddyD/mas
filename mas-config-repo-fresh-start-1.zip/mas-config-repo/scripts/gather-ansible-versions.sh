#!/usr/bin/env bash
# Gather the versions the RUNNING Ansible install (drmasapp) uses, and print the
# exact values to paste into envs/drroc4.env so the fresh GitOps install matches.
# Read-only: this script only runs `oc get`. Nothing is changed.
#
# Usage: ./gather-ansible-versions.sh            (defaults below)
#        ANSIBLE_INSTANCE_ID=drmasapp SLS_NS=ibm-sls ./gather-ansible-versions.sh
set -uo pipefail

INSTANCE="${ANSIBLE_INSTANCE_ID:-drmasapp}"
CORE_NS="${CORE_NS:-mas-${INSTANCE}-core}"
MANAGE_NS="${MANAGE_NS:-mas-${INSTANCE}-manage}"
SLS_NS="${SLS_NS:-ibm-sls}"
CATALOG_NS="openshift-marketplace"

line(){ printf '%s\n' "------------------------------------------------------------"; }
sub(){ # ns -> print "name | channel | installedCSV" for ibm-* subs
  oc get sub -n "$1" -o jsonpath='{range .items[*]}{.metadata.name}{"|"}{.spec.channel}{"|"}{.status.installedCSV}{"\n"}{end}' 2>/dev/null
}

echo; line; echo " OPERATOR CATALOG (master pin)"; line
CAT_IMG=$(oc get catalogsource ibm-operator-catalog -n "$CATALOG_NS" -o jsonpath='{.spec.image}' 2>/dev/null)
echo "spec.image (what's configured): $CAT_IMG"
# resolved digest actually being served (from the running catalog pod)
CAT_DIGEST=$(oc get pod -n "$CATALOG_NS" -l olm.catalogSource=ibm-operator-catalog \
  -o jsonpath='{.items[0].status.containerStatuses[0].imageID}' 2>/dev/null)
echo "running pod imageID (resolved):  $CAT_DIGEST"

echo; line; echo " SUBSCRIPTIONS / CSVs (the parity targets)"; line
printf "%-16s %-26s %-12s %s\n" "AREA" "SUBSCRIPTION" "CHANNEL" "INSTALLED CSV"
while IFS='|' read -r n c v; do [ -n "$n" ] && printf "%-16s %-26s %-12s %s\n" "core($CORE_NS)" "$n" "$c" "$v"; done < <(sub "$CORE_NS")
while IFS='|' read -r n c v; do [ -n "$n" ] && printf "%-16s %-26s %-12s %s\n" "manage" "$n" "$c" "$v"; done < <(sub "$MANAGE_NS")
while IFS='|' read -r n c v; do [ -n "$n" ] && printf "%-16s %-26s %-12s %s\n" "sls($SLS_NS)" "$n" "$c" "$v"; done < <(sub "$SLS_NS")
echo "(cert-manager / DRO — search all namespaces:)"
oc get sub -A -o jsonpath='{range .items[*]}{.metadata.namespace}{" "}{.metadata.name}{"|"}{.spec.channel}{"|"}{.status.installedCSV}{"\n"}{end}' 2>/dev/null \
  | grep -Ei 'cert-manager|data-reporter|dro|truststore' | sort -u

echo; line; echo " PRODUCT CR VERSIONS"; line
echo -n "Suite (core):    "; oc get suite -n "$CORE_NS"        -o jsonpath='{.items[0].status.versions.reconciled}{"\n"}' 2>/dev/null
echo -n "ManageWorkspace: "; oc get manageworkspace -n "$MANAGE_NS" -o jsonpath='{.items[0].status.versions.reconciled}{"\n"}' 2>/dev/null
echo -n "SLS:             "; oc get licenseservice -n "$SLS_NS"  -o jsonpath='{.items[0].status.versions.reconciled}{"\n"}' 2>/dev/null

# Derive channels for the paste block
CORE_CH=$(sub "$CORE_NS"   | awk -F'|' '/^ibm-mas\|/{print $2; exit}')
MAN_CH=$(sub "$MANAGE_NS"  | awk -F'|' '/manage/{print $2; exit}')
SLS_CH=$(sub "$SLS_NS"     | awk -F'|' '/^ibm-sls\|/{print $2; exit}')
DIG="${CAT_DIGEST##*@}"

echo; line; echo " >>> PASTE INTO envs/drroc4.env (verify first) <<<"; line
echo "MAS_CHANNEL=${CORE_CH:-CHECK_ABOVE}"
echo "MAS_APP_CHANNEL=${MAN_CH:-CHECK_ABOVE}"
echo "SLS_CHANNEL=${SLS_CH:-CHECK_ABOVE}"
echo "# Digest pin (preferred):"
echo "MAS_CATALOG_IMAGE=icr.io/cpopen/ibm-maximo-operator-catalog@sha256"
echo "MAS_CATALOG_VERSION=${DIG:-CHECK_POD_IMAGEID_ABOVE}"
echo
echo "NOTE: the INSTALLED CSV column above is your exact parity target."
echo "After the fresh GitOps install, re-run this for drgitopsapp and the CSVs must match."
