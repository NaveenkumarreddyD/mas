#!/usr/bin/env bash
# Greenfield SLS handoff: SLS generates its registration_key/url/ca at runtime.
# IBM's auto-writer (07-postsync-update-sm) only writes to AWS Secrets Manager,
# so with HashiCorp Vault this step is manual. Run AFTER the SLS LicenseService
# reaches Initialized, then sync the drgitopsapp-sls-system SlsCfg app.
#
# Requires: oc logged in, vault logged in (VAULT_ADDR/VAULT_TOKEN), KV v2 at secret/.
set -euo pipefail
INSTANCE="${INSTANCE_ID:-drgitopsapp}"
CLUSTER="${CLUSTER_ID:-drroc4}"
ACCOUNT="${ACCOUNT_ID:-mas}"
SLS_NS="${SLS_NS:-mas-${INSTANCE}-sls}"     # set SLS_NS=ibm-sls if pointing at the shared Ansible SLS
VPATH="secret/${ACCOUNT}/${CLUSTER}/${INSTANCE}/sls"

echo "Reading SLS runtime values from namespace: $SLS_NS"
REGKEY=$(oc get licenseservice sls -n "$SLS_NS" -o jsonpath='{.status.registrationKey}' 2>/dev/null)
URL=$(oc get cm sls-suite-registration -n "$SLS_NS" -o jsonpath='{.data.url}' 2>/dev/null)

# serving CA — try the common secret names, fall back to listing
CA=""
for s in sls-cert-ca-secret sls-tls-secret sls-cert-secret; do
  CA=$(oc get secret "$s" -n "$SLS_NS" -o jsonpath='{.data.ca\.crt}' 2>/dev/null | base64 -d 2>/dev/null) && [ -n "$CA" ] && break
done

echo "  registrationKey: ${REGKEY:-<EMPTY>}"
echo "  url:             ${URL:-<EMPTY>}"
echo "  ca.crt:          $( [ -n "$CA" ] && echo '<captured>' || echo '<EMPTY - check secret name below>')"
[ -z "$CA" ] && { echo "Could not auto-find the SLS CA secret. Available secrets:"; oc get secret -n "$SLS_NS" | grep -Ei 'cert|tls|ca'; }

if [ -z "${REGKEY}" ] || [ -z "${URL}" ] || [ -z "${CA}" ]; then
  echo "Refusing to write incomplete values to Vault. Resolve the EMPTY fields and re-run."; exit 1
fi
vault kv put "$VPATH" url="$URL" registration_key="$REGKEY" ca.crt="$CA"
echo "Wrote $VPATH. Now: argocd app sync drgitopsapp-sls-system.${CLUSTER}"
