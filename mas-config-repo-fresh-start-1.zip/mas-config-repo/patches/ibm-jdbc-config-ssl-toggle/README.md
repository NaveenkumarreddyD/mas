# Patch: make JDBC SSL configurable (support non-SSL Oracle)

## Why
Ansible builds this cluster with **non-SSL** Oracle:
`jdbc:oracle:thin:@//stl-dmasdb-21.lac1.biz:1521/DEMAS`, `SSL_ENABLED=false`, port 1521.

The stock `ibm-mas/gitops` chart `instance-applications/130-ibm-jdbc-config/templates/01-suite_jdbccfg.yaml`
**hardcodes** `spec.config.sslEnabled: true` and always emits a `certificates[]` block, so it cannot
reproduce the Ansible setup. This patch makes SSL driven by a value (`jdbc_ssl_enabled`, default false)
and only emits certificates when SSL is on.

## Where it goes
This patches the **ibm-mas-gitops mirror** repo (NOT mas-config-repo):
`instance-applications/130-ibm-jdbc-config/templates/01-suite_jdbccfg.yaml`

Replace that file with `01-suite_jdbccfg.yaml` from this folder, commit to your mirror, and keep the
delta when you re-sync from upstream IBM (it's a small, isolated change).

## Config side (already done in mas-config-repo)
`base/instance/ibm-mas-suite-configs.yaml.tpl` now sets `jdbc_ssl_enabled: false` and omits `jdbc_ca_pem`.
With SSL off, no Oracle CA is needed; the loader no longer stores `jdbc-system#ca.crt`.

To switch a future instance to TLS (TCPS): set `jdbc_ssl_enabled: true`, restore `jdbc_ca_pem.crt`
pointing at the Vault CA key, and use a TCPS url (port 2484).
