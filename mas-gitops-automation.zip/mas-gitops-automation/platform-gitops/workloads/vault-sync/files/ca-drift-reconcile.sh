#!/usr/bin/env sh
# CronJob init 2/2 (vault image). Compares Vault's mongo#ca.crt and
# sls-mongo#ca.crt against the live CA staged by ca-drift-harvest.sh.
# On drift: patch Vault, VERIFY the write landed (read-back compare), and flag
# /work/drifted so the refresh container hard-refreshes the consuming apps.
#
# Safety rules:
#   - never write if no live CA was staged (harvest skipped)
#   - never create a creds-less secret: if username is missing at the path,
#     load-secrets.sh hasn't run -> warn and skip (don't kv put a CA-only secret)
#   - write-back verification: a silent partial write fails the Job loudly,
#     which surfaces in Job history / alerts instead of as a stale CA later.
set -e
rm -f /work/drifted

if [ ! -s /work/live-ca.pem ]; then
  echo ">> no live CA staged — nothing to reconcile"
  exit 0
fi

export VAULT_ADDR="${VAULT_ADDR:?}"
[ -n "${VAULT_CACERT:-}" ] && export VAULT_CACERT
JWT="$(cat /var/run/secrets/kubernetes.io/serviceaccount/token)"
VAULT_TOKEN="$(vault write -field=token auth/kubernetes/login role="${VAULT_ROLE:?}" jwt="$JWT")"
export VAULT_TOKEN

IP="${ACCOUNT_ID:?}/${CLUSTER_ID:?}/${INSTANCE_ID:?}"
KV="${KV_MOUNT:-secret}"
live_sum="$(sha256sum /work/live-ca.pem | cut -d' ' -f1)"
echo ">> live CA sha256: $(echo "$live_sum" | cut -c1-16)…"

drift=0
for p in mongo sls-mongo; do
  # creds must exist first (written by load-secrets.sh) — never create CA-only secrets
  if ! vault kv get -field=username "$KV/$IP/$p" >/dev/null 2>&1; then
    echo ">> WARN $KV/$IP/$p has no creds yet (load-secrets.sh not run?) — skipping"
    continue
  fi
  vault kv get -field=ca.crt "$KV/$IP/$p" > /work/vault-ca.pem 2>/dev/null || : > /work/vault-ca.pem
  vsum="$(sha256sum /work/vault-ca.pem | cut -d' ' -f1)"
  if [ "$vsum" = "$live_sum" ]; then
    echo ">> $KV/$IP/$p#ca.crt in sync ($(echo "$vsum" | cut -c1-16)…)"
    continue
  fi
  echo ">> DRIFT $KV/$IP/$p#ca.crt vault=$(echo "$vsum" | cut -c1-16)… live=$(echo "$live_sum" | cut -c1-16)… — patching"
  vault kv patch "$KV/$IP/$p" ca.crt=@/work/live-ca.pem
  # write-back verification
  vault kv get -field=ca.crt "$KV/$IP/$p" > /work/verify.pem
  if [ "$(sha256sum /work/verify.pem | cut -d' ' -f1)" != "$live_sum" ]; then
    echo "ERROR: write-back verify FAILED for $KV/$IP/$p#ca.crt — Vault still differs after patch"
    exit 1
  fi
  echo ">> patched + verified $KV/$IP/$p#ca.crt"
  drift=1
done

if [ "$drift" = "1" ]; then
  touch /work/drifted
  echo ">> drift corrected — consumer apps will be hard-refreshed"
else
  echo ">> no drift — no refresh needed"
fi
