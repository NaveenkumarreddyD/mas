#!/usr/bin/env bash
# CronJob init 1/2 (oc image). Reads the LIVE dedicated-Mongo CA and stages it
# at /work/live-ca.pem for the reconcile container to compare against Vault.
#
# Non-fatal by design: if the Mongo CA secret isn't present (Mongo torn down,
# not yet deployed, or mid-rotation) we stage nothing and the cycle is a no-op.
# We NEVER want the reconciler to clobber Vault with an empty value.
set -euo pipefail
mkdir -p /work; : > /work/live-ca.pem
NS="${MONGO_NS:?}"; CR="${MONGO_CR:?}"

for s in "${CR}-ca" "${CR}-server-cert"; do
  for k in 'ca\.crt' 'tls\.crt'; do
    oc get secret "$s" -n "$NS" -o jsonpath="{.data.$k}" 2>/dev/null | base64 -d > /work/live-ca.pem 2>/dev/null || true
    if grep -q 'BEGIN CERTIFICATE' /work/live-ca.pem 2>/dev/null; then
      echo ">> live CA harvested from $NS/$s (key ${k//\\/})"
      exit 0
    fi
  done
done

echo ">> no live Mongo CA found in $NS (Mongo absent or not Ready) — skipping this cycle"
: > /work/live-ca.pem
exit 0
