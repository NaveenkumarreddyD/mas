#!/usr/bin/env bash
set -euo pipefail
# Copy the DEDICATED Mongo's cert-manager CA into Vault (mongo#ca.crt AND sls-mongo#ca.crt), then
# hard-refresh the consuming apps. Run ONCE after the dedicated Mongo is Ready, and after any CA rotation.
#   ./sync-mongo-ca.sh <cluster.env>
#
# HARDENED (v2):
#   - validates VAULT_TOKEN up front so an expired token can't silently no-op the patch
#   - write-back verification: reads the value back from Vault after each patch and
#     sha256-compares it to the pushed file; any mismatch exits non-zero LOUDLY
#   - NOTE: the mongo-ca-drift CronJob (workloads/vault-sync) now continuously
#     reconciles this same value in-cluster; this script remains the bootstrap /
#     manual-recovery path.
ENVFILE="${1:?usage: sync-mongo-ca.sh <cluster.env>}"
# shellcheck disable=SC1090
set -a; . "$ENVFILE"; set +a
: "${ACCOUNT_ID:?}"; : "${CLUSTER_ID:?}"; : "${INSTANCE_ID:?}"
MONGO_NS="${MONGO_NS:-mongo-${INSTANCE_ID}}"; MONGO_CR="${MONGO_CR:-${INSTANCE_ID}-mongo}"
VAULT_NS="${VAULT_NS:-vault}"; VAULT_POD="${VAULT_POD:-vault-0}"; VADDR="${VADDR:-http://127.0.0.1:8200}"; KV="${KV_MOUNT:-secret}"
ARGO_NS="${ARGO_NS:-openshift-gitops}"
[[ -z "${VAULT_TOKEN:-}" ]] && { echo "ERROR: export VAULT_TOKEN first" >&2; exit 1; }
IP="$ACCOUNT_ID/$CLUSTER_ID/$INSTANCE_ID"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

vrun(){ oc exec -n "$VAULT_NS" "$VAULT_POD" -- sh -c "export VAULT_ADDR=$VADDR VAULT_TOKEN='$VAULT_TOKEN'; $*"; }

# --- token guard: fail fast on expired/insufficient token --------------------
if ! vrun "vault token lookup >/dev/null 2>&1"; then
  echo "ERROR: VAULT_TOKEN is invalid or expired (vault token lookup failed)." >&2
  echo "       Re-export a valid token (init-vault.sh prints the root token) and retry." >&2
  exit 1
fi

# CA from the cert-manager CA secret (<resource>-ca), key ca.crt (fallback tls.crt)
for s in "${MONGO_CR}-ca" "${MONGO_CR}-server-cert"; do
  for k in ca.crt tls.crt; do
    oc get secret "$s" -n "$MONGO_NS" -o jsonpath="{.data.${k//./\\.}}" 2>/dev/null | base64 -d > "$TMP/ca.pem" 2>/dev/null || true
    grep -q 'BEGIN CERTIFICATE' "$TMP/ca.pem" 2>/dev/null && break 2
  done
done
grep -q 'BEGIN CERTIFICATE' "$TMP/ca.pem" 2>/dev/null || { echo "ERROR: no CA found in $MONGO_NS (looked at ${MONGO_CR}-ca / -server-cert). Is the Mongo Ready?"; oc get secret -n "$MONGO_NS" | grep -Ei 'ca|cert'; exit 1; }

PUSH_SUM="$(sha256sum "$TMP/ca.pem" | cut -d' ' -f1)"
echo ">> live CA sha256: ${PUSH_SUM:0:16}…"

oc cp "$TMP/ca.pem" "$VAULT_NS/$VAULT_POD:/tmp/mongo-ca.pem"
vrun "vault kv patch $KV/$IP/mongo ca.crt=@/tmp/mongo-ca.pem; \
      vault kv patch $KV/$IP/sls-mongo ca.crt=@/tmp/mongo-ca.pem; rm -f /tmp/mongo-ca.pem"
echo ">> patched $KV/$IP/mongo#ca.crt and $KV/$IP/sls-mongo#ca.crt"

# --- write-back verification: prove the patch actually landed ----------------
verify_fail=0
for p in mongo sls-mongo; do
  GOT_SUM="$(vrun "vault kv get -field=ca.crt $KV/$IP/$p" | sha256sum | cut -d' ' -f1)"
  if [[ "$GOT_SUM" == "$PUSH_SUM" ]]; then
    echo ">> VERIFIED $KV/$IP/$p#ca.crt (${GOT_SUM:0:16}…)"
  else
    echo "ERROR: write-back verify FAILED for $KV/$IP/$p#ca.crt — Vault holds ${GOT_SUM:0:16}…, pushed ${PUSH_SUM:0:16}…" >&2
    verify_fail=1
  fi
done
[[ "$verify_fail" == "1" ]] && exit 1

oc rollout restart deploy/openshift-gitops-repo-server -n "$ARGO_NS" >/dev/null 2>&1 || true
for app in "${INSTANCE_ID}-mongo-system.${CLUSTER_ID}" "${INSTANCE_ID}-sls-system.${CLUSTER_ID}"; do
  oc annotate application "$app" -n "$ARGO_NS" argocd.argoproj.io/refresh=hard --overwrite 2>/dev/null || true
done
echo ">> repo-server restarted + mongo/sls apps hard-refreshed."
