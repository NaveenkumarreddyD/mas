# MAS GitOps Automation Hardening — Install & Ops Guide

Goal: make the CA-staleness failure class **structurally impossible to repeat**, reduce the
manual seams to the irreducible minimum, and give every remaining failure mode a loud signal.

What broke before: the Mongo CA in Vault was valid-but-stale (didn't match the cert the live
replica set presents). Preflight's PEM-shape check passed it; the one-shot vault-sync hook had
no reason to re-run; the operator failed TLS verification with the generic
"MongoDB configuration was unable to be verified" on both SYSTEMDB and SLS.

The design principle of this bundle: **one source of truth (the live `<resource>-ca` secret),
continuously reconciled into Vault, with verification at every write, and gates that compare
against the live value — not just the shape of the stored one.**

---

## What's in the bundle

```
platform-gitops/
  workloads/vault-sync/
    files/ca-drift-harvest.sh          NEW  reads live Mongo CA (skip-safe)
    files/ca-drift-reconcile.sh        NEW  sha256 compare vs Vault; patch + read-back verify
    templates/40-ca-drift-cronjob.yaml NEW  CronJob reconciler (default every 10m)
    templates/05-configmap.yaml        PATCHED  ships the two new scripts
  scripts/
    preflight-vault.sh                 PATCHED  token guard + check_ca_matches_live (full phase)
    sync-mongo-ca.sh                   PATCHED  token guard + write-back verification
monitoring/
  prometheusrule-mas-gitops-automation.yaml  OPTIONAL  alerts: reconciler failing, sync jobs failing, Vault sealed
```

### values.yaml addition (workloads/vault-sync/values.yaml)

```yaml
# continuous Mongo-CA reconciliation (self-heals Vault vs live cert-manager CA)
caDrift:
  enabled: true
  schedule: "*/10 * * * *"
```

No changes needed in `gitops/templates/app-28-vault-sync-mongo.yaml` — the default is on, and
the CronJob reuses the existing SA, Vault k8s-auth **writer** role, scoped RBAC, and
`refresh.sh`. Zero new permissions.

---

## How the reconciler closes the gap

Every cycle (10 min default):

1. **harvest-live-ca** (oc image) — reads `drgitopsapp-mongo-ca` (`ca.crt`, fallback
   `tls.crt`) from `mongo-drgitops`. If Mongo is absent/not-Ready it stages nothing and the
   cycle is a no-op — it can never clobber Vault with an empty value.
2. **reconcile** (vault image) — k8s-auth login as `mas-gitops-writer`, sha256-compares the
   live CA to `mongo#ca.crt` and `sls-mongo#ca.crt`. On drift: `kv patch`, then **reads the
   value back and verifies** it matches (a 403 / partial write fails the Job loudly). Skips
   any path with no creds yet (won't create CA-only secrets before `load-secrets.sh`).
3. **refresh-if-drifted** (oc image) — only if drift was corrected: hard-refreshes
   `drgitopsapp-mongo-system.drroc4` and `drgitopsapp-sls-system.drroc4` so AVP re-renders
   the MongoCfg/SLS configs with the fresh CA, and the MAS operator re-verifies on the next
   reconcile.

Consequences:

- **Teardown/redeploy with a reused Vault**: stale CA self-heals within one cycle. The
  teardown no longer needs to remember to clear Vault CA paths (still good hygiene).
- **cert-manager CA rotation** (10y duration today, but any manual regen): self-heals.
- **`sync-mongo-ca.sh` forgotten or run with a bad token**: self-heals; the script remains
  the *bootstrap* path (prepare-prereqs still calls it so the very first render is fresh
  without waiting a cycle).

## How the hardened gates prevent a bad sync

- **`preflight-vault.sh --phase full`** now FAILS if the Vault CA ≠ live CA (byte compare),
  in addition to the existing shape checks. Since `sync-mas-account-root.sh` runs full
  preflight first, **a stale CA can no longer reach the MongoCfg render**. It also validates
  `VAULT_TOKEN` with `vault token lookup` up front, so an expired token is a clear error at
  second zero instead of "missing field" noise mid-run.
- **`sync-mongo-ca.sh`** verifies its own write landed (read-back compare) and exits
  non-zero otherwise — no more silent no-ops.

## Alerting (optional but recommended for production)

Apply `monitoring/prometheusrule-mas-gitops-automation.yaml` (or fold into your
`mas-grafana-monitoring` chart):

| Alert | Meaning | First response |
|---|---|---|
| `MongoCADriftReconcilerFailing` | reconciler Jobs failing ≥15m | `oc logs job/<name> -n openshift-gitops --all-containers`; check Vault sealed / writer role |
| `VaultRegistrationSyncFailed` | sls/dro/mongo PostSync hook failing | same log path; SLS/BAS registration won't flow until green |
| `VaultSealed` | a Vault node sealed (node reboot) | unseal with saved keys; everything AVP-dependent is down until then |

---

## Install steps

1. Copy the bundle files into `platform-gitops` at the same paths (overwrite the two scripts
   and `05-configmap.yaml`; add the two `files/` scripts, the CronJob template, and the
   `caDrift` block in `workloads/vault-sync/values.yaml`).
2. `bash -n` the scripts, `helm template workloads/vault-sync` to sanity-check rendering.
3. Commit + push `platform-gitops`. The `vault-sync-mongo-drgitopsapp` app picks up the new
   ConfigMap entries and CronJob on its next sync (automated+selfHeal — it will just appear).
4. Verify: `oc get cronjob mongo-ca-drift-drgitopsapp -n openshift-gitops`, then after a cycle
   `oc logs job/$(oc get job -n openshift-gitops -o name | grep mongo-ca-drift | tail -1 | cut -d/ -f2) -n openshift-gitops --all-containers`
   → expect `in sync` lines (or one `DRIFT … patched + verified` on the first corrective run).
5. Optionally apply the PrometheusRule.

## Fresh-deploy flow (unchanged commands, now self-verifying)

```
bash scripts/init-vault.sh                     # manual seam: keys + root token (store securely)
export VAULT_TOKEN=<root>                      # token guard now validates this everywhere
./scripts/install-gated.sh --yes envs/drroc4.env
#   = check-env (blocks CHANGE_ME incl. MAS_DOMAIN)
#   -> deploy.sh (vault-auth, load-secrets, static preflight, render, push)
#   -> prepare-prereqs.sh (mongo up -> sync-mongo-ca [verified] -> FULL preflight [CA-match gate])
./scripts/sync-mas-account-root.sh envs/drroc4.env   # re-runs full preflight; renders configs with verified-fresh CA
./scripts/sync-runtime-registration.sh envs/drroc4.env  # after SLS Ready
```

## What stays manual (irreducible seams) and why

| Seam | Why it can't be GitOps'd | Mitigation |
|---|---|---|
| Vault init/unseal + root token custody | unseal keys must not live in the cluster they protect | `init-vault.sh` automates the mechanics; `VaultSealed` alert; consider transit auto-unseal from a second Vault later |
| `load-secrets.sh` inputs (entitlement key, license.dat, JDBC creds) | external secrets a human must supply once per env | generate-once + `vget` reuse makes re-runs idempotent |
| `MAS_DOMAIN` and env values | per-cluster business decision | `check-env.sh` blocks `CHANGE_ME*`; fix the committed `drroc4.env` placeholder before the fresh deploy |
| account-root sync gate | deliberate human gate before IBM charts deploy | full preflight (now CA-matching) is the objective go/no-go |

## Residual risks (known, accepted, monitored)

- **AVP is render-time, not runtime**: any Vault change still needs a hard refresh to reach
  the cluster. The reconciler and `sync-mongo-ca.sh` both do this for the Mongo/SLS configs;
  for other values (e.g. rotated JDBC password) the same pattern applies — patch Vault, then
  hard-refresh the consuming app. If that becomes frequent, the longer-term move is Vault
  Secrets Operator / External Secrets for *your own* charts (IBM's charts are AVP-shaped, so
  they stay on AVP).
- **Catalog tag floats** (`v9-240625-amd64` re-resolvable): you already documented the digest
  pin option in `docs/version-alignment.md`; for production, pin by digest and correct the
  doc line claiming this tag ships Core 8.11.26 (cluster proved the `8.11.x` head is 8.11.12).
- **10-minute drift window**: between a Mongo CA change and the next reconcile cycle,
  verification can fail transiently. The MAS operator retries continuously, so it converges
  without intervention; tighten `caDrift.schedule` if you want a smaller window.
