merge-key: "${ACCOUNT_ID}/${CLUSTER_ID}/${INSTANCE_ID}"

# JDBC is intentionally NOT configured here. IBM's 130-ibm-jdbc-config chart hardcodes
# sslEnabled:true; our Oracle is non-SSL (TCP/1521). The non-SSL JdbcCfg is created by our
# own chart in extras/jdbc-nonssl/ (deployed by extras/jdbc-nonssl-application.yaml) so the
# IBM charts stay untouched. Only sls + mongo are registered through suite-configs.
ibm_mas_suite_configs:
  - mas_config_name: "${INSTANCE_ID}-sls-system"
    mas_config_chart: ibm-mas-sls-config
    mas_config_scope: system
    mas_workspace_id:
    mas_application_id:
    mas_config_kind: "slscfgs"
    mas_config_api_version: "config.mas.ibm.com"
    use_postdelete_hooks: true
    registration_key: "<path:secret/data/${ACCOUNT_ID}/${CLUSTER_ID}/${INSTANCE_ID}/sls#registration_key>"
    url: "<path:secret/data/${ACCOUNT_ID}/${CLUSTER_ID}/${INSTANCE_ID}/sls#url>"
    ca:
      crt: "<path:secret/data/${ACCOUNT_ID}/${CLUSTER_ID}/${INSTANCE_ID}/sls#ca.crt>"

  - mas_config_name: "${INSTANCE_ID}-mongo-system"
    mas_config_chart: ibm-mas-mongo-config
    mas_config_scope: system
    mas_workspace_id:
    mas_application_id:
    mas_config_kind: "mongocfgs"
    mas_config_api_version: "config.mas.ibm.com"
    use_postdelete_hooks: true
    username: "<path:secret/data/${ACCOUNT_ID}/${CLUSTER_ID}/${INSTANCE_ID}/mongo#username>"
    password: "<path:secret/data/${ACCOUNT_ID}/${CLUSTER_ID}/${INSTANCE_ID}/mongo#password>"
    config:
      hosts:
        - host: "<path:secret/data/${ACCOUNT_ID}/${CLUSTER_ID}/${INSTANCE_ID}/mongo#host>"
          port: 27017
      configDb: admin
      authMechanism: DEFAULT
      retryWrites: false
      credentials:
        secretName: "system-mongo-credentials"
    certificates:
      - alias: ca
        crt: "<path:secret/data/${ACCOUNT_ID}/${CLUSTER_ID}/${INSTANCE_ID}/mongo#ca.crt>"
