# ibm-mas-gitops source mirror

Purpose: internal, read-only mirror of IBM MAS GitOps source repository.

IBM source repository:

```text
https://github.com/ibm-mas/gitops.git
```

Pinned release for this implementation:

```text
8.0.0
```

This repository should not contain environment-specific config. Do not edit IBM charts here.
All environment config belongs in `config-repo`.

## Create/update internal GitLab mirror

Create an empty GitLab repo named `ibm-mas-gitops`, then run:

```bash
cd /tmp
rm -rf ibm-mas-gitops

git clone https://github.com/ibm-mas/gitops.git ibm-mas-gitops
cd ibm-mas-gitops
git checkout 8.0.0

git remote remove origin
git remote add origin CHANGE_ME_IBM_MAS_GITOPS_SOURCE_REPO_URL

git push origin HEAD:refs/heads/8.0.0
git push origin refs/tags/8.0.0
```

Use this internal mirror in the MAS Account Root Application as:

```yaml
source:
  repo_url: CHANGE_ME_IBM_MAS_GITOPS_SOURCE_REPO_URL
  revision: "8.0.0"
```

## Verify

```bash
git ls-remote CHANGE_ME_IBM_MAS_GITOPS_SOURCE_REPO_URL | grep 8.0.0
```

Expected refs:

```text
refs/heads/8.0.0
refs/tags/8.0.0
```
