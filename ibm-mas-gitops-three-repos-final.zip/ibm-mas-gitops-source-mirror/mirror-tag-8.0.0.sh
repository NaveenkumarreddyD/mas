#!/usr/bin/env bash
set -euo pipefail

TARGET_REPO_URL="${1:-}"
if [[ -z "$TARGET_REPO_URL" ]]; then
  echo "Usage: $0 <internal-gitlab-ibm-mas-gitops-repo-url>" >&2
  exit 1
fi

WORKDIR="/tmp/ibm-mas-gitops-mirror-8.0.0"
rm -rf "$WORKDIR"

git clone https://github.com/ibm-mas/gitops.git "$WORKDIR"
cd "$WORKDIR"
git checkout 8.0.0

git remote remove origin
git remote add origin "$TARGET_REPO_URL"

git push origin HEAD:refs/heads/8.0.0
git push origin refs/tags/8.0.0

echo "Mirrored IBM MAS GitOps 8.0.0 to $TARGET_REPO_URL"
