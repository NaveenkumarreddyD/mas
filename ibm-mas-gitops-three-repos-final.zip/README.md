# IBM MAS GitOps - three repo package

This package contains the three GitLab repositories for the IBM-aligned MAS GitOps architecture:

```text
platform-repo/
  Management cluster bootstrap: Vault, AVP, repo credentials, target cluster registration, MAS Account Root.

config-repo/
  IBM MAS GitOps Config Repository. Renders final account/cluster/instance YAML under mas/.

ibm-mas-gitops-source-mirror/
  Helper README/script to create the internal read-only mirror of IBM MAS GitOps tag 8.0.0.
```

Architecture:

```text
Management OpenShift cluster
  OpenShift GitOps / ArgoCD
  HashiCorp Vault
  ArgoCD Vault Plugin
  One IBM MAS Account Root Application
    -> deploys MAS/Manage to registered target clusters drroc4 and roc4
```

Install order:

1. Create GitLab repos: `platform-repo`, `config-repo`, `ibm-mas-gitops`.
2. Mirror IBM source repo tag `8.0.0` using `ibm-mas-gitops-source-mirror/`.
3. Push `platform-repo/` to the platform repo.
4. Push `config-repo/` to the config repo.
5. In management ArgoCD, create repository Secrets for platform, config, and IBM source repos.
6. Update `platform-repo/values-management.yaml` with real repo URLs and Vault host.
7. Apply `platform-repo/bootstrap.yaml` on the management cluster.
8. Sync Vault, initialize/unseal Vault, configure Vault with `platform-repo/vault/setup-vault.sh`.
9. Patch ArgoCD repo-server for AVP with `platform-repo/argocd/argocd-cr-avp-sidecar-patch.yaml` after verifying your OpenShift GitOps CR supports the fields.
10. Register target clusters using `platform-repo/cluster-registration/register-cluster.sh`.
11. Update `config-repo/envs/*.env`, run `config-repo/render.sh --all`, load MAS secrets into Vault, commit/push config repo.
12. Manually sync `ibm-mas-account-root`.

Important caveat: IBM MAS GitOps documents AWS Secrets Manager as the supported Secrets Vault today. This package uses HashiCorp Vault through AVP as an on-prem technical pattern; validate support expectations before production.
